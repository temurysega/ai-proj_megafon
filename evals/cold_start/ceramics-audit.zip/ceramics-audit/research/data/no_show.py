from math import ceil, sqrt

overall = 24 / 120
weekday = 6 / 60
weekend = 18 / 60
lower_rate = 0.20
pooled = (weekend + lower_rate) / 2
required_per_arm = ceil((
    1.96 * sqrt(2 * pooled * (1 - pooled))
    + 0.84 * sqrt(weekend * (1 - weekend) + lower_rate * (1 - lower_rate))
) ** 2 / (weekend - lower_rate) ** 2)
print({"overall": overall, "weekday": weekday, "weekend": weekend,
       "gap_pp": (weekend - weekday) * 100, "required_per_arm": required_per_arm})
